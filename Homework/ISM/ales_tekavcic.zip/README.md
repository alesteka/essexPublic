###	- Information Security Management, June 2024
###	- Ales Tekavcic PG. Dip. CS.
###	- Pampered Pets Attack Tree
### ----------------------------------------------------------------------------------------

### Packages and Software used:

Packages:
- PyYAML: 6.0.1
- graphviz: 0.20.3
- pylint: 3.2.5

Software:
- Python: 3.12.4
- GraphViz: 12.0.0-win64

### ----------------------------------------------------------------------------------------

To run the script one should follow the steps below:

## 1. Install GraphViz Software

This standalone software is needed together with python GraphViz library in order to produce graphical representation of the attack tree. Instructions to install the software:

Go to [the link](https://graphviz.org/download/) and choose 'graphviz-12.0.0 (64-bit) EXE installer' as depicted on [the screenshot](./images/GraphVizExecutable.png).

Start the executables and choose the option to add the GraphViz to the system path for [all users](./images/GraphViz_1.png). Click next and choose [destination folder to](./images/GraphViz_2.png) C:\Program Files\Graphviz. This destination is highly recommended, because the Python script is bundled to that location binary files. If other destination folder is choosen then Python path to that bin folder should also be manually changed, within the script. After clicking next, we can choose [to not create shortcuts](./images/GraphViz_3.png) and the installation can begin.


## 2. Running the program

To run the program [unzip ales_tekavcic.zip](./images/extract_zip.png) and go to the unzipped folder. Type cmd in the file explorer [address bar](./images/type_cmd.png) so that Command Prompt opens up.
Inside CMD Prompt create venv: <br>["python -m venv ." and activate the script ".\\\Scripts\activate"](./images/CreateAndActivateVenv.png) <br>
If activation doesn't work, we can [Set-ExecutionPolicy RemoteSigned -Scope CurrentUser](./images/ExecutionPolicy_and_activate_venv.png) for the current user. 
After activating venv we can [pip install -r requirements.txt](./images/install_requirements.png).

The env is ready and we can start the [the script](./images/start_script.png), do [unit test](./images/UnitTest.png) and run the pylint:<br>
[Before](./images/beforePylint.png) and [After](./images/afterPylint.png) the resolution of the errors.

## 3. App Description

The threat modelling app renders the attack tree of possible threats exposed to Pampered Pets company. There are two branches, one named ["before the digitalisation"](./images/before_dgtz.png) and another ["after digitalisation"](./images/after_dgtz.png). The former comprises of monetary costs, faced by the company (these include cost of goods, cost of rent, etc.), and therefore, represent traditional risks. On the other hand, we have STRIDE model as a technique used to model contemporary threats. This organised approach identifies possible security threats of a digitalised company, hence the most appropriate metric to assess threat degree is risk probability, nevertheless, financial losses could also be considered.

When the app starts, it reads the structure of the attack tree according to .yml file, whereas a user is prompted to enter monetary costs and risk probabilities. After the entries, [the calculations are completed](./images/testing_calculations_across_nodes.png) and the graph gets displayed in a web browser interface. The final probability is calculated with simple cross formula across all nodes.

### 4. Uninstall GraphViz (Optionally)

[In the Control Panel remove the software](.\images\uninstall.png)


#### References:

GraphViz Executable Packages (n.d.) GraphViz. Available from: https://graphviz.org/download/ [Accessed 12 July 2024]