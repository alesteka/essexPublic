import unittest
from threat_model import Tree

class TestTree(unittest.TestCase):

    def test_evaluate_color(self):
        self.assertEqual(Tree.evaluate_color(10), '#ffb3c1')
        self.assertEqual(Tree.evaluate_color(30), '#ff758f')
        self.assertEqual(Tree.evaluate_color(60), '#c9184a')
        self.assertEqual(Tree.evaluate_color(90), '#800f2f')

if __name__ == '__main__':
    unittest.main()