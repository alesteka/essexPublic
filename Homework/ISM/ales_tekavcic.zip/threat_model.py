"""
Author:     Ales Tekavcic PG. Dip. CS.
Module:     Information Security Management
Date:       June 2024
"""
import math
import os
import yaml
from graphviz import Digraph

class Tree:
    """The class Tree comprises of methods designed
    to iterate through the provided yaml file, calculate
    input probabilities and render final threat model."""
    dict_before_dgtlz = {}
    dict_after_dgtlz = {}

    def __init__(self):
        self.dot = Digraph(graph_attr={'rankdir':'LR'})

    def prepare_user_input_values(self, data_: dict) -> None:
        """
        The function handles yml file seperately for before and after
        digitalization options since they have different nested structures.
        """
        for _, company in data_.items(): # _ character is an empty placeholder.
            for state, risks in company.items():
                if state == 'before digitalization': # Corresponding to a nested option in yml file we invoke the "graph builder" method.
                    Tree.before_digitalization(state, risks)

                if state == 'after digitalization':
                    Tree.after_digitalization(state, risks)

    @classmethod # I've decided to go with @classmethods to utilize the power of class variables. This way I avoided returning dictionaries and passing them back and forth between methods
    def before_digitalization(cls, state: str, risks: dict) -> None:
        """
        This function iterates through the traditional risk options
        that contain monetary values (£) which a user is prompted to enter.
        """
        sum_monetary_pound = 0
        for risk in risks: # Risk in risks are traditional threats expressed as cost of goods, cost of rent...
            cls.dict_before_dgtlz[risk] = {}
            while True: # Ensure to enter integer. Upper value/limit is not confined.
                try:
                    value = int(input(f"Monetary cost (£) for: {risk} -> "))
                    sum_monetary_pound = sum_monetary_pound + value # We need the sum of monetary costs in order to display the value on the first node level of the graph.
                    cls.dict_before_dgtlz[risk] = value
                    break
                except (ValueError, TypeError):
                    print("Integer required")

        cls.dict_before_dgtlz[state] = {} # We need this empty "before digitalization" dictionary to append above calculated monetary value to the state node (for the later use, when the graph gets actually constructed)
        cls.dict_before_dgtlz[state] = sum_monetary_pound

    @classmethod
    def after_digitalization(cls, state: str, risks: dict) -> None:
        """
        In contrast to the before digitalization function,
        the function after digitalization comprises of
        probability evaluation of stride risks (probability of phishing attack, data leakage...),
        for which a user is prompted to enter their probability in percentage points.
        """

        state_sum = 0
        
        """The below count_state variable is needed for the final calculation. In its core,
        it adds full percentage points (100) for each iteration (+100, +100...).
        The purpose of this is to be able to calculate final cross calculation formula.
        For example, Spoofing has two threats, meaning that count_state would be 100 + 100,
        ultimately reaching 1100 as this is the number of all possible threats (in yml file).
        When a user also inputs threat probabilities in percentage points from 0 to 100,
        the sum of these values are divided by above described state_count, meaning
        that we get final after digitalization probability value in percentages (not percentage points).
        The similar purpose has count variable on the line 83 except that it evaluates itself on 
        the level of threats (spoofing, tampering, repudiation, ...) instead of entire state (after digitalization).
        (example can be seen on testing_calculations_across_nodes.png).
        """
        count_state = 0 

        for stride in risks:
            cls.dict_after_dgtlz[stride] = {}
            threat_sum = 0
            threat_percentage = 0
            count = 0
            for threat in risks[stride]:
                cls.dict_after_dgtlz[stride][threat] = {}
                while True: # Ensure the value is int between 0 and 100 pct. points
                    try:
                        value = int(input(f"Probability of: {threat} -> "))
                        if 0 <= value <= 100:
                            color = Tree.evaluate_color(value)
                            threat_sum = threat_sum + value
                            count = count + 100
                            cls.dict_after_dgtlz[stride][threat][value] = color
                            break
                        print("Value has to be between 0 and 100")
                    except (ValueError, TypeError):
                        print("Value has to be between 0 and 100")

            print(f"Threat percentage points = {threat_sum}")
            print(f"All percentage points = {count}")
            threat_percentage = math.ceil((threat_sum / count) * 100)
            str_ = f"{stride} probability"
            color = Tree.evaluate_color(threat_percentage)
            cls.dict_after_dgtlz[str_] = {}
            cls.dict_after_dgtlz[str_][threat_percentage] = color
            print(f"threat_percentage = {threat_percentage}")
            count_state = count_state + count
            state_sum = state_sum + threat_sum

        print(f"""
        ------------------------------------------------------------
        Sum of All Percentage Points = {count_state}
        Sum of Threat Percentage Points = {state_sum}
        Final probability of after digitalization:
        {count_state} ... 100% 
        {state_sum}   ... x%
        {count_state}x = {state_sum} * 100
        x = {state_sum * 100} / {count_state}
        x = {(state_sum * 100) / count_state}
        x = rounded({math.ceil((state_sum * 100) / count_state)})
        ------------------------------------------------------------
        """)

        threat_percentage = math.ceil((state_sum / count_state ) * 100)
        str_ = f"{state} probability"
        color = Tree.evaluate_color(threat_percentage)
        cls.dict_after_dgtlz[str_] = {}
        print(cls.dict_after_dgtlz)
        cls.dict_after_dgtlz[str_][threat_percentage] = color

    def construct_graph(self, data_: dict, dict_before_dgtlz: dict, dict_after_dgtlz: dict) -> None:
        """
        After calculations, this function iterates through
        yml file again and append above calculations to the risks/nodes/edges.
        These calculations are therefore depicted on the final graph,
        constructed by below iterations of each 'node'.
        """
        for root, company in data_.items():
            root_name = root
            self.dot.node(root, label=root_name, shape='box')
            for state, risks in company.items():
                if state == 'before digitalization':
                    state = f'Before digitalization monetary cost = {dict_before_dgtlz[state]} £'
                    self.build_graph(root, state)
                    for risk in risks:
                        risk = f"Cost of {risk} = {dict_before_dgtlz[risk]} £"
                        self.build_graph(state, risk)
                if state == 'after digitalization':
                    state_key = f"{state} probability"
                    state_color = list(dict_after_dgtlz[state_key].values())[0]
                    state_prob = list(dict_after_dgtlz[state_key].keys())[0]
                    state_tail = f'After digitalization risk probability = {state_prob} %'
                    self.build_graph(root, state_tail, state_color)
                    for stride in risks:
                        stride_key = f"{stride} probability" # To access specific probability key
                        stride_number = list(dict_after_dgtlz[stride_key])[0]
                        stride_color = dict_after_dgtlz[stride_key][stride_number]
                        stride_head = f"{stride} = {stride_number} %"
                        self.build_graph(state_tail, stride_head, stride_color)
                        for threat in risks[stride]:
                            threat_value = list(dict_after_dgtlz[stride][threat])[0]
                            threat_color = dict_after_dgtlz[stride][threat][threat_value]
                            threat_head = f'{threat} Risk possibility = {threat_value} pct. points'
                            self.build_graph(stride_head, threat_head, threat_color)

    def build_graph(self, tail_name, head_name, color = None) -> None:
        """
        The purpose of the function is to avoid repeating
        building nodes and edges for each nested risk/threat
        """
        self.dot.node(head_name, shape='box', fillcolor = color, style='filled') # head_name is current node, while below edge drags actual arrows between parent node and a child. e.g. after digitalization (parent) --> spoofing (child); after digitalization (parent) --> tampering (child), ...
        self.dot.edge(tail_name, head_name)

    @staticmethod
    def evaluate_color(value_: int) -> str:
        """Returns a color contrast as a string, based on the
        input probability, given as a number of percentage points"""
        if value_ <= 25:
            return '#ffb3c1'
        if 25 < value_ <= 50:
            return '#ff758f'
        if 50 < value_ <= 75:
            return '#c9184a'
        return '#800f2f'

    def view_(self) -> None:
        """Render constructed tree diagram"""
        self.dot.view()

if __name__ == "__main__":
    
    #The path below has to point to the bin directory where the software was installed.
    os.environ["PATH"] += os.pathsep + 'C:/Program Files/Graphviz/bin' #This automatically adds GraphViz executable software to the system's path. We need both, the library (gets installed within py. env) and the executable Software.
    
    with open("./pampered_pets_data.yml", encoding = 'UTF-8') as stream:
        data = yaml.safe_load(stream) #Reading yaml file

    tree = Tree() #We initialize GraphViz Graph
    tree.prepare_user_input_values(data) #This method prompts a user to enter input values (monetary for traditional risks, and percentage points for stride risk probabilities). Once the inputs are ready and evaluated with corresponding color (according to evaluate_color method), the script continues with below method, where building the model finally starts.
    tree.construct_graph(data, Tree.dict_before_dgtlz, Tree.dict_after_dgtlz)
    tree.view_()
