import csv
import random
import logging

class Route():
    """
    The purpose of the latter class is to read the data from a file.
    It simulates a race track, as a path, that driverless car follows.
    """
    def __init__(self) -> None:
        pass

    def coordinates(self):
        logging.basicConfig(filename='LogFile.log', encoding='utf-8', level=logging.DEBUG)
        logging.info("Inside coordinates method of the Route class")
        route = []
        
        with open('./Data/raceT.txt') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            header = True

            for row in csv_reader:
                if header == True:
                    header = False
                else:                    
                    route.append(row[2:4])
        logging.info(f"Route\n {route}\n has been loaded")
        raceSize = len(route)

        try:
            if type(route) != type(list()) or type(route[0]) != type(list()) or type(raceSize) != type(int()):
                logging.warning("Route should be type list of lists holding two string values.")
                logging.critical("Data corrupted, provide proper data!")
                raise Exception
            else:
                return route, raceSize #    Returns tuple
        finally:
            logging.info("Finished importing data")        
            logging.info("Route travelled data logging started")        

    #   This method returns a random value either between the lanes or slightly out of the lanes, with the same probability. It simulates 'path detection'. 
    @staticmethod
    def generate_current_stream_location(left_lane, right_lane):
        avg = (left_lane + right_lane)/2
        absolute_diff_left = left_lane - (avg - left_lane)
        absolute_diff_right = right_lane + (right_lane - avg)
        stream_location_value = round(random.uniform(absolute_diff_left, absolute_diff_right),3) #  Random value between absolute differences on the left/right scope.
        return stream_location_value
    
#print(Route().coordinates())

