#	Driverless car - Final assignment - OOP
#	Ales Tekavcic PGCert. CS
#	10.4.2023
#	***Program version used: Python 3.11.0***

1. Description of the solution implementation.

The main focus of the coding part has been devoted to the overall design. The latter has been changed to some degree, compared to the original design of the UML class diagram. The major and most notable change can be seen in the Sensor class, whereas the instance attributes: Left sensor data, Right sensor data and Front sensor data have been replaced with only one sensor depicting a stream of the data. However, the data structure that has been used has remained the same (<List<Obstacle>>). I have decided to omit the three sensors and replace them with only one, as it has substantially alleviated the overall implementation, yet the architecture and foremost the logic stayed the same. As the matter of this (Sensor) class, there is only one method (SensorDetectionRoute) implemented with the purpose to bring the data from Obstacle and Route class to one common place, ultimately generating stream of data. Overall, the main purpose of the Sensor is to simulate the detection of the environment and eventually transmit the data to the DecisionModel Class.

DecisionModel class is the shortest in the sense of number of lines, yet it implements the logic of stack and queue. In it's main part, it sends the decision to Driverless class as an actuator, responsible to execute the decisions. DecisionModel 'processes' the stream of data that comes from the sensor, whereas based on the certain type of the data, the decision model then 'triggers/invokes' methods like: accelerating(), avoiding() and turn(). 

The next class is Route class, designed to mimic the path that the driverless car is about to undergo. The class reads the data from a .txt file, that has been obtained from the GitHub repository. The latter class assumes coordinates in the following format: [6.42, 7.32] as left and right lane coordinates. Each row consist of the above mentioned format, depicting the entire route. The data structure then gets furthermore transformed (string to float etc.) to satisfy the constraints of 'streaming data' by the Sensor class. Moreover, the Route class has an additional static method named generate_current_stream_location(), whose purpose is to generate a random current location, so that the Sensor class eventually detects lanes as an input from previous method (coordinates()).

The Obstacle class is similar to the above mentioned class, in the sense of generating random objects as obstacles, whereas each obstacle has its own type. In our case Pedestrian, Cyclist, Vehicle.

The main class, namely Driverless realizes all the instructions that come from DecisionModel. Furthermore, it is the entry and closing point of the program, responsible for guiding through the entire simulation with two methods: start_drive() and stop(). As a class variable there has been added timeDelay, in order to simulate dynamical/realistic decisions.


2. Instructions: How to execute the code

The code can be executed through an IDE's main terminal/shell, whereas the initial input should be as follows (assuming that the Python interpreter is already installed): Python <path to the python executable file>. E.g. Python MainDriverless.py. Any additional parameters are not required, because the program monitors entire process.

References:
Heilmeier, A. (2021). Racetrack – database. TUM – Institute of Automotive Technology. GitHub. Available from: https://github.com/TUMFTM/racetrack-database [Accessed 10 March 2023]
