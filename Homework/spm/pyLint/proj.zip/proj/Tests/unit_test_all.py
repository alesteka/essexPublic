import unittest
from Route import Route
from Obstacle import *
from MainDriverless import Driverless

#run program:
#python -m unittest unit_test_all.py

"""
There are three classes namely:
TestRouteClass, TestObstacleClass, TestMainDriverlessClass
Each responsible to test it's own methods.
There are two/four additional methods in each class, created with the purpose to monitor and to track the tests with ease.
E.g. setUpClass method denotes the name of the class over which the test has been conducted, similarly tearDownClass method
denotes the end of the class that has been tested. On the other hand setUp and tearDown are the methods that get executed before each
test_method call.
"""


class TestRouteClass(unittest.TestCase):
    
    @classmethod
    def setUpClass(cls):
        print("Started testing Route class")
        cls.left_lane = round(6.225, 3)
        cls.right_lane = round(6.403, 3)
    
    @classmethod
    def tearDownClass(cls):
        print("\nFinished testing Route class")
    
    def setUp(self):
        self.obj_route = Route.coordinates(Route)
        self.obj_generate_location = round(Route.generate_current_stream_location(self.left_lane, self.right_lane), 3)
    
    def tearDown(self) -> None:
        pass

    def test_route_coordinates_obj_type(self):
        self.assertIsInstance(self.obj_route[0], list)

    def test_route_coordinates_obj_value_type(self):
        self.assertIsInstance(self.obj_route[0][0], list)        

    def test_route_coordinates_obj_value_length(self):
        self.assertEqual(len(self.obj_route[0][0]), 2)
        
    def test_route_coordinates_obj_value_coordinates_type(self):
        self.assertIsInstance(self.obj_route[0][0][0], str)

    def test_route_coordinates_obj_value_coordinates_size(self):
       self.assertIsInstance(self.obj_route[1], int)

    def test_route_generate_current_stream_value_type(self):
        self.assertIsInstance(self.obj_generate_location, float)

    def test_route_generate_current_stream_value_in_range(self):
        try:
            import numpy as np
            if self.obj_generate_location in np.arange(self.left_lane, self.right_lane):
                assert True
        except:
            assert False      

      
class TestObstacleClass(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        print("Started testing Obstacle class")
    
    @classmethod
    def tearDownClass(cls):
        print("\nFinished testing Obstacle class")
    
    def setUp(self):
        self.cyclist = Cyclist()
        self.pedestrian = Pedestrian()
        self.vehicle = Vehicle()
        self.obstacle = Obstacle()
    
    def tearDown(self) -> None:
        pass

    def test_route_abstract_methods(self):
        type_cyclist = self.cyclist.type()
        type_pedestrian = self.pedestrian.type()
        type_vehicle = self.vehicle.type()       
        self.assertEqual(type_cyclist, "Cyclist")
        self.assertEqual(type_pedestrian, "Pedestrian")
        self.assertEqual(type_vehicle, "Vehicle")

    def test_route_generate_method(self):
        test_list = [self.obstacle.generate() for i in range(2)]
        self.assertIsInstance(test_list[0], type(self.obstacle.generate()))

class TestMainDriverlessClass(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        print("Started testing Driverless class")
    
    @classmethod
    def tearDownClass(cls):
        print("\nFinished testing Driverless class")
    
    def setUp(self):
        self.car = Driverless()
    
    def tearDown(self) -> None:
        pass

    def test_get_speed(self):
        assert type(self.car.get_speed()) == type(int())

    def test_accelerating(self):
        """
        This Docstring is a type of 'self-reflection' and can be ignored...
        self.car.accelerating() doesn't work and it returns the following error:
        TypeError: Driverless.set_speed() takes 1 positional argument but 2 were given.
        It fails here self.set_speed(Driverless),
        Because we have two positional arguments self(one that has been instantiated (self.car)) and Driverless.
        The solution is bellow:
        """
        Driverless.accelerating(Driverless) #   Calling class method of itself (not through the instance of a class).
        assert Driverless.currentSpeed > 1

   
    def test_turn(self):
        Driverless.turn("")
        assert Driverless.currentSpeed > 0

    def test_updateLocation(self):
        Driverless.updateLocation(1, [4.5, 5.7])
        Driverless.updateLocation(2, [4.8, 6.3])
        assert len(Driverless.currentLocation) == 2
