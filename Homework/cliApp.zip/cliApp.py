import click
import os

"""
To run the program type python cliApp.py
To display the commands type: python cliApp.py --help
To display arguments of an command type: python cliApp.py <command-name> --help
Example: python cliApp.py ADD --help
full example: python cliApp.py ADD -fn 1 -sn 2
"""

# Function responsible to group the commands for easier invocation. It also improves
# readability
@click.group
def commands():
    pass

# Function that lists the content of current directory
@click.command("LIST", help="Lists content of current directory")
def list_content():
    files = [f for f in os.listdir('.') if os.path.isfile(f)]
    click.echo(files)

# Simple function that sums two numbers, entered as parameters
@click.command("ADD", help="Adds two numbers together")
@click.option("-fn","--firstnumber", prompt=False, default=0, help="Enter first number")
@click.option("-sn","--secondnumber", prompt=False, default=0, help="Enter second number")
def add_numbers(firstnumber=0, secondnumber=0):
    result = firstnumber + secondnumber
    click.echo(result)

# Display message
@click.command("EXIT", help="Exit the shell")
def exit():
    click.echo("Action ended")


commands.add_command(list_content)
commands.add_command(add_numbers)
commands.add_command(exit)

if __name__=="__main__":
    commands()