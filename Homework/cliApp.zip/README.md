1. What are the two main security vulnerabilities with your shell?
2. What is one recommendation you would make to increase the security of the shell?
3. Add a section to your e-portfolio that provides a (pseudo)code example of changes you would make to the shell to improve its security.

1. The cliApp doesn't include error handling for ADD option. It just returns a generic error instead of raising appropriate exception and notifying the user. The second issue is that the user can potentially enter any number, which could cause the system to hang.

2. To increase security, the main focus should be on implementing regex or other constraints on the passed parameters. This way, we would get more control over the program. Another improvement would be to implement appropriate error handling and to use unittests.

3. Changes that should be made, to confine the input range of the numbers:

def add_numbers(firstnumber=0, secondnumber=0):
    r1 = re.search("^[0-9]{0,5}?$|^100000$", str(firstnumber))
    r2 = re.search("^[0-9]{0,5}?$|^100000$", str(secondnumber))
    if r1 and r2:
        result = firstnumber + secondnumber
        click.echo(result)
    else:
        raise Exception("Number is too long. Provide lower number")