import random
from abc import ABC

"""
The first four classes are called, when generate method of the Obstacle class is invoked.
This first three classes (omitting the first class) depict the types of the obstacles.
"""

class abstrObstacle(ABC):   
    def type(self):
        pass

class Cyclist(ABC):
    def __init__(self):
        pass
    def type(self):
        return type(self).__name__

class Pedestrian(ABC):
    def __init__(self):
        pass
    def type(self):
        return type(self).__name__

class Vehicle(ABC):
    def __init__(self):
        pass   
    def type(self):
        return type(self).__name__


class Obstacle():
    """
    Class that generates random Obstacle objects in random sequence.
    """
    def __init__(self):
        pass

    def generate(self):
        number_of_obstacles = random.randint(0, 2)

        for obs in range(number_of_obstacles):
            obstacle_type = random.randint(1, 3)

            if obstacle_type == 1:
                obstacle = Pedestrian()
                yield obstacle
            elif obstacle_type == 2:
                obstacle = Cyclist()
                yield obstacle
            elif obstacle_type == 3:
                obstacle = Vehicle()
                yield obstacle
            else:
                pass

#o = Obstacle()
#for i in o.generate():
#    print(i.type())
