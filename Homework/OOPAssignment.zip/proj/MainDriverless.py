import random
import inspect
import logging
import time
import Route
import Obstacle

"""
Student: Ales Tekavcic, PGCert., CS.
Date: 10.4.2023
"""

class Driverless():   
    """
    This is the main class of a Driverless car.
    It has been created with the purpose to depict a vehicle/motor as an actuator,
    responsible to execute the instructions coming from the DecisionModel class.
    """
    currentSpeed = 0
    currentLocation = {}
    timeDelay = 5

    def __init__(self):
        self.sensorRoute = Sensor()
 
    def start_drive(self):    
        self.sensorRoute.sensorDetectionRoute()
    
    def stop(self):
        print("Car has stopped")
    
    def get_speed(self):
        return self.currentSpeed

    def set_speed(self):
        caller = inspect.stack()[1][3] #	Returns the name of the method, from which has been called.
        if caller == 'avoiding':
            if self.currentSpeed < 0:
                self.currentSpeed = 10
            self.currentSpeed = self.currentSpeed - 2
        else:
            self.currentSpeed = self.currentSpeed + 3

    def accelerating(self):
        self.set_speed(Driverless)

    @staticmethod
    def avoiding(obstacle):
        print(f"{obstacle} Detected ... decreasing speed ... avoiding {obstacle}")
        time.sleep(Driverless.timeDelay)
        Driverless.set_speed(Driverless)
    
    @staticmethod
    def turn(direction):
        if direction == 'left_lane_detected':
            print("Left lane detected ... Turning right")
            time.sleep(Driverless.timeDelay)
        elif direction == 'right_lane_detected':
            print("Right lane detected ... Turning left")
            time.sleep(Driverless.timeDelay)
        else:
            print("No lane detected ... Going forward")
            time.sleep(Driverless.timeDelay - 2)        
            Driverless.accelerating(Driverless)
    
    @classmethod
    def updateLocation(cls, location, coordinates):
        cls.currentLocation[location] = coordinates
        pass
    

class Sensor(Driverless):
    """
    The latter class is the central point of the program, due to multiple inputs 
    deriving from Route and Obstacle classes. It is therefore the most important class,
    responsible for simulating and consequently processing otherwise real world data.
    """
    def __init__(self):
        self.decisionModel = DecisionModel()
        self.route = Route.Route()

    #   Method primarily responsible to bring the data to one common place.
    #   i.e. simulating stream of data, that sensor detects in the form of lane and obstacle detection. 
    def sensorDetectionRoute(self):
        location = 1
        RaceTrack = self.route.coordinates()
        RaceSize = RaceTrack[1]

        for coordinates in RaceTrack[0]:
            obstacle = Obstacle.Obstacle()
            _sensor_data = []
            left_lane = float(coordinates[0])
            right_lane = float(coordinates[1])
            lane_value = Route.Route.generate_current_stream_location(left_lane, right_lane) #  Gets random point. If it is between lanes, car moves forward, otherwise it turns either right or left.
            
            if lane_value < left_lane:
                self.updateLocation(location, coordinates)
                location += 1
                lane = "left_lane_detected"
                if max(self.currentLocation) == RaceSize:
                    self.currentSpeed = 0
                    logging.info("Route travelled data logging finished")        
                print("─" * 115 + f"\nCurrent speed is {self.currentSpeed} \t Current location is {max(self.currentLocation)} .... {RaceSize} \n")
            elif lane_value > right_lane:
                self.updateLocation(location, coordinates)
                location += 1
                lane = "right_lane_detected"
                if max(self.currentLocation) == RaceSize:
                    self.currentSpeed = 0
                    logging.info("Route travelled data logging finished")        
                print("─" * 115 + f"\nCurrent speed is {self.currentSpeed} \t Current location is {max(self.currentLocation)} .... {RaceSize} \n")
            else:
                self.updateLocation(location, coordinates)
                location += 1
                lane = "going_forward"
                if max(self.currentLocation) == RaceSize:
                    self.currentSpeed = 0
                    logging.info("Route travelled data logging finished")        
                print("─" * 115 + f"\nCurrent speed is {self.currentSpeed} \t Current location is {max(self.currentLocation)} .... {RaceSize} \n")

            logging.basicConfig(filename='CarLocation.log', encoding='utf-8', level=logging.DEBUG)
            logging.info(f"{self.currentLocation}")

            if max(self.currentLocation) == RaceSize:
                print("Destination reached.")
                return
            else:
                pass

            #  Generates random obstacle objects (based on the Object class) and append them to the list,
            #  which furthermore gets populated with specific 'lane-decision', finally creating stream of data,
            #  ready to be processed by the DecisionModel class.
            for obst in obstacle.generate(): 
                _sensor_data.append(obst)
            
            self.decisionModel.sensordata.append(_sensor_data)
            insert_value_at_the_begginingEnd = random.randint(1, 2)

            if insert_value_at_the_begginingEnd == 1:
                self.decisionModel.sensordata.insert(0, lane)
            else:
                self.decisionModel.sensordata.append(lane)
            
            print(f"stream Data = {self.decisionModel.sensordata}\n")
            self.decisionModel.process_data()

        return


class DecisionModel():
    """
    Class designed to send the instructions/decisions back to Driverless car as an actuator, that executes the decisions.
    The main part is simulating stack and queue, as there is different sequence of each stream.
    """
    def __init__(self) -> None:
        self.sensordata = []
    
    def process_data(self):
        while len(self.sensordata) != 0:
            obstacle = self.sensordata.pop()
            if isinstance(obstacle, list):
                if len(obstacle) == 0:
                    Driverless.accelerating(Driverless)
                else:
                    while len(obstacle) != 0:
                        obs = obstacle.pop(0)
                        #print(f"{obs.type()} Detected")
                        Driverless.avoiding(obs.type())
            else:
                Driverless.turn(obstacle)


if __name__ == '__main__':
    car = Driverless()
    car.start_drive()
    car.stop()






            










